<script setup>
import loginView from './views/loginView.vue';
</script>

<template>
<loginView></loginView>
</template>

<style scoped>
</style>
